#!/bin/bash
set -e

echo "Installing Pegasus..."

sudo cp .p_sysdata /opt/.p_sysdata
sudo chmod 444 /opt/.p_sysdata
sudo chown root:root /opt/.p_sysdata
sudo chattr +i /opt/.p_sysdata

sudo cp pegasus /usr/local/bin/pegasus
sudo chmod +x /usr/local/bin/pegasus

echo "Installation complete."
